<?php

use Illuminate\Support\Facades\Route;
use App\Http\controllers\TaskManagementController;
use App\Http\controllers\LoginController;
use App\Http\controllers\RegisterUserController;




Route::middleware(['auth', 'auth.session'])->group(function (){
    Route::controller(TaskManagementController::class)->group(function(){
    Route::get('/dashboard', 'index')->name('tasklist');
    Route::get('/newtask', 'create')->name('createtask');
    Route::post('/store', 'store');
    Route::get('/detail/{id}', 'show');
    Route::get('/edit/{id}', 'edit');
    Route::post('/update', 'update');
    Route::get('/delete/{id}', 'destroy');
    });
    });
    
    Route::controller(LoginController::class)->group(function(){
    Route::get('/login', 'login');
    
    Route::post('/login', 'authenticate');
    Route::get('/logout', 'logout');    
});
    
Route::controller(RegisterUserController::class)->group(function(){
    Route::get('/register', 'create');
    Route::post('/register', 'store');
    
  
});
