@include('common/header')

<div style="margin:50px">
  <div class="alert alert-primary" role="alert">
 <h1>LOGIN </h1>
</div>
@if($errors->any())
<div class="alret alert-danger">
  @foreach($errors->all() as $error)
  <li>{{$error}}</li>
@endforeach
</div>
@endif

<form method="post" action="{{url('login')}}">
    @csrf
  <div class="mb-3">
    <label for="email" class="form-label">Email </label>
    <input type="email" class="form-control" id="email" name="email">
   </div>

  <div class="mb-3">
    <label for="Password" class="form-label">Password</label>
    <input type="password" class="form-control" id="Password" name="password">
  </div>

  <button type="submit" class="btn btn-primary">Login</button>
</form><br>
For New User
<a href="{{url('register')}}">Register</a> here..!
<!-- @include('common/footer') -->
