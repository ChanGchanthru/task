@include('common/header')
  <div class="alert alert-primary" role="alert">
 <h1>Task List</h1>
</div>

    <table class="table table-striped">
        <tr>
            <th>#</th>
            <th>Task Name</th>
            <th>Due_Date</th>
            <th>Priority</th>
            <th>Action</th>
        </tr>
        @forelse($tasks as $task)
        <tr>
            <td>{{$task->id}}</td>
            <td>{{$task->name}}</td>
            <td>{{$task->due_date}}</td>
            <td>{{$task->end_at}}</td>
               <td><a class="btn btn-primary btn-sm" href="{{url('detail/'.$task->id)}}" style="background-color:">view details</button></td>
               <td><a class="btn btn-primary btn-sm" href="{{url('edit/'.$task->id)}}">edit</button>
            </td>
        </tr>
        @empty
        <tr>
            <td  colspan="5" align="center">No Task found...!</td>
        </tr>
        @endforelse
</table><br>
<div>{!! $tasks->links()!!}</div><br>
<a href="{{url('newtask')}}" role="button" class="btn btn-primary mb-5" style="background-color:greenyellow">Add New Task</a>
@include('common/footer')
