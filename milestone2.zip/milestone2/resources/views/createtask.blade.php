@include('common/header')
    <div style="margin:50px">
  <div class="alert alert-primary" role="alert">
 <h1>Create Task</h1>
</div>
@if($errors->any())
<div class="alret alert-danger">
  @foreach($errors->all() as $error)
  <li>{{$error}}</li>
@endforeach
</div>
@endif


 <!-- form -->
 <form method="post" action="{{url('store')}}">
  @csrf
  <div class="mb-3">
    <label for="taskname" class="form-label">Task Name</label>
    <input type="text" class="form-control" id="taskname" name="taskname">
  </div>

  <div class="mb-3">
  <label for="description" class="form-label">Description</label>
    <input type="text" class="form-control" id="description" name="description">
  </div>  
  <div class="mb-3">
  <label for="startdate" class="form-label">Due_Date</label>
    <input type="date" class="form-control" id="startdate" name="startdate">
  </div>
  <div class="mb-3"> <label for="priority">Priority:</label><br>
<select id="priority" name="priority">
<option value="low">Low</option>
<option value="medium">Medium</option>
<option value="high">High</option>
</select><br><br></div>

  <div class="col-12">
    <button type="submit" class="btn btn-primary">Sumbit</button>
  </div>
</form>
<a class="btn btn-primary mt-2" href="{{url('/')}}" role="button">View Task List</a>
@include('common/footer')
