@include('common/header')

  <div class="alert alert-primary" role="alert"> 
    <h1>Task Details #{{$task->id}}</h1> </div> 
    <table class="table">
        <tr><td width="30%">Task Id</td><td>{{ $task->id }}</td></tr>
        <tr> <td>Name: </td> <td>{{ $task->name }}</td></tr>
        <tr> <td>Description:</td><td>{{ $task->description }}</td></tr>
        <tr> <td>Due_Date: </td><td>{{ $task->Due_date }}</td></tr>
        <tr> <td>priority:</td><td>{{ $task->priority }}</td></tr>
       
  
    
    
    </table>  
  
<a href="{{url('newtask')}}" role="button" class="btn btn-primary mb-5">Add New Task</a>
<a class="btn btn-primary mb-5" href="{{url('dashboard')}}" role="button">View Task List</a><br>
<a class="btn btn-danger mb-2" href="{{url('delete/'.$task->id)}}" role="button">Delete this Task </a>

    @include('common/footer')
