<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\User;

class RegisterUserController extends Controller
{
    public function create(){
        return view('register');
    }


    public function store(Request $request){
        $validated = $request->validate([
            'name' => "required|max:50|string",
            'email' => "required|email|string|max:100",
            'password' => "required|confirmed",

            
        ]);

        $user = new User;
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->save();

        return view('login');
    }
}