<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\TaskManagement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;


class TaskManagementController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
    //    $tasks = TaskManagement::all();
    $tasks = User::find(Auth::user()->id)->tasks()->simplePaginate(5);
       return view('tasklist',["tasks"=>$tasks]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
       return view('createtask');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
                'taskname'=>'required|max:255',
                'description'=> 'required',
                'duedate'=> 'required|date',
                'priorityy'=>'required',
       ]);

    $task = new TaskManagement;
 $task->name = $request->taskname;
 $task->user_id=auth()->user()->id;
 $task->description = $request->description;
 $task->due_at = $request->startdate;
 $task->priority = $request->priority;
 $task->save();

  return redirect()->route('tasklist');
    }
    /**
     * Display the specified resource.
     */
    public function show(TaskManagement $taskManagement , $id)
    {
        // return view('task_details', ['id' => $taskManagement]);
        // $task = DB::table('task_management')->where('id', $id)->first();
        // dd($task);

         $taskDetail = TaskManagement::find($id);
         if(isset($taskDetail->id)){
        return view('showtask',['task'=>$taskDetail]);
         }
        return redirect()->route('showtask');

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(TaskManagement $taskManagement, $id)
    {
        $taskDetail = TaskManagement::find($id);
        return view('edittask', ['task' => $taskDetail]);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, TaskManagement $taskManagement)
    {
        $validated = $request->validate([
            'id'=>'required',
            'taskname'=>'required|max:255',
            'description'=> 'required',
            'startdate'=> 'required|date',
            'enddate'=>'required|date',
   ]);
   $taskManagement = TaskManagement::find($request->id);
   if(! Gate::allows('update-task_management',$taskManagement)){
    abort(403);
   }

   $taskManagement = TaskManagement::find($request->id);
   if($taskManagement){
      $taskManagement->name = $request->taskname;
      $taskManagement->description = $request->description;
      $taskManagement->start_at = $request->startdate;
      $taskManagement->end_at = $request->enddate;
      $taskManagement->save();
    }
    return redirect()->route('tasklist');
}


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(TaskManagement $taskManagement, $id)
    {
   $taskManagement = TaskManagement::find($id);
        if($taskManagement){
            $taskManagement->delete();
        }
        return redirect()->route('tasklist');
    }
}
